package com.backend.careerplanningbackend.config;

import com.backend.careerplanningbackend.tool.GenerateTool;
import com.backend.careerplanningbackend.util.SystemConstants;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
//import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AiCommonConfiguration {
    /**
     * 题库生成模拟器游戏用ChatClient对象，用于模拟
     * @param model 使用OpenAI的模型
     * @return
     */
    @Bean
    public ChatClient gameChatClient(OpenAiChatModel model/*, ChatMemory chatMemory*/, GenerateTool generateTool) {
        return ChatClient
                .builder(model)// 选择模型
                .defaultSystem(SystemConstants.GAME_SYSTEM_PROMPT)// 系统设置
                .defaultAdvisors(new SimpleLoggerAdvisor())// 添加日志记录
//                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())// 添加会话记忆功能
                .defaultTools(generateTool)
                .build();
    }
    /**
     * 配置会话历史存储
     * @return
     */
//    @Bean
//    public ChatMemory chatMemory() {
//        return MessageWindowChatMemory.builder().build(); // 使用 MessageWindowChatMemory 作为会话历史存储策略，默认使用内存存储，窗口大小20
//        // return new InSqlChatMemory(); // 使用自定义的 InSqlChatMemory 作为会话历史存储策略，使用数据库存储
//    }
}
 