package com.backend.careerplanningbackend.controller;

import com.backend.careerplanningbackend.domain.dto.InterviewQAGenerateRequest;
import com.backend.careerplanningbackend.domain.po.Result;
import com.backend.careerplanningbackend.service.InterviewQAService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * InterviewQAController
 * 八股文问答接口
 * 主要功能：
 * 1. 接收前端请求，调用 InterviewQAService 生成八股文问答
 * 2. 支持生成八股文问答并存储到数据库
 * 3. 支持查询已生成的题库
 * 4. 统一返回 Result 对象封装响应结果
 * 5. 记录日志，便于调试和监控
 * @module InterviewQAController
 */
@Slf4j
@RestController
@RequestMapping("/interview")
@RequiredArgsConstructor
public class InterviewQAController {

    private final InterviewQAService interviewQAService;

    /**
     * 生成程序员八股文问答（调用旧的 AI 服务端）
     */
    @PostMapping("/generate")
    public Result generateQA(@RequestBody(required = false) InterviewQAGenerateRequest request) {
        log.info("收到八股文生成请求: {}", request);
        return interviewQAService.generateQA(request);
    }

    /**
     * 使用 Spring AI 生成题库并存储到数据库
     */
    @PostMapping("/generate-and-store")
    public Result generateAndStoreQA(@RequestBody(required = false) InterviewQAGenerateRequest request) {
        log.info("收到 Spring AI 生成并存储题库请求: {}", request);
        return interviewQAService.generateAndStoreQA(request);
    }

    /**
     * 从数据库查询已生成的题库
     */
    @GetMapping("/query")
    public Result queryQA(
            @RequestParam(required = false) String topic,
            @RequestParam(required = false) String stackLevel) {
        log.info("查询题库: topic={}, stackLevel={}", topic, stackLevel);
        return interviewQAService.queryQA(topic, stackLevel);
    }
}

