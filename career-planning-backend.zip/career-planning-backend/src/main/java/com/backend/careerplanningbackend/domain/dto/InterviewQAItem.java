package com.backend.careerplanningbackend.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 单条八股文问答模型
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewQAItem {
    /** 场景题、架构题,选择题,填空题题等 */
    private Integer selectType;
    /** 题目所属主题 */
    private String topic;
    /** 技术级别 */
    private String stackLevel;
    /** 问题 */
    private String question;
    /** 答案 */
    private String answer;
    /** 数据来源：AI 或 fallback */
    private String source;
}

