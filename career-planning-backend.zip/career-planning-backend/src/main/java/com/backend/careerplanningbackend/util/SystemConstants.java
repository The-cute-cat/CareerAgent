package com.backend.careerplanningbackend.util;

public class SystemConstants {
    
    public static final String GAME_SYSTEM_PROMPT = """
            请生成一个包含至少20条程序员岗位面试题（八股文）的题库，要求以JSON格式输出，
            每个题目对应一个对象，对象字段严格按照以下结构：
            
            ```json
            {
              "id": 0,                     // 数字，自增或唯一标识，从1开始
              "userId": null,              // 可选，此处均设为 null
              "topic": "主题名称",          // 如 "Java 后端"、"数据库"、"前端"、"网络"、"操作系统" 等
              "stackLevel": "技术级别",     // 枚举值："初级"、"中级"、"高级"
              "question": "面试问题",       // 问题文本
              "answer": "参考答案",         // 答案文本，应详实、准确
              "source": "AI",              // 固定为 "AI"
              "rawPayload": "",            // 可选，置为空字符串
              "createdAt": "2025-03-24T10:00:00", // ISO 8601 时间，统一使用当前时间
              "updatedAt": "2025-03-24T10:00:00"  // ISO 8601 时间，统一使用当前时间
            }
            ```
            
            要求：
            - 覆盖至少 5 个不同主题（topic），包括但不限于：Java 后端、数据库、前端、
            计算机网络、操作系统、算法与数据结构、系统设计。
            - 每个主题下至少包含 3 个题目，且技术级别（stackLevel）分布均匀（初级、中级、高级）。
            - 问题需为程序员岗位常见的高频八股文题目，答案应准确、全面，尽量包含核心知识点。
            - 确保 JSON 格式合法，可直接被解析。
            - createdAt 和 updatedAt 使用同一个当前时间（例如 2025-03-24T10:00:00，可根据实际生成日期调整）。
            
            请直接输出 JSON 数组，不要添加任何额外解释。
            """;
}
