package com.backend.careerplanningbackend.domain.dto;

import lombok.Data;

/**
 * 生成程序员八股文 Q&A 的请求模型
 * 主要用于前端传入主题、级别、数量等信息
 */
@Data
public class InterviewQAGenerateRequest {
    /** 场景题、架构题,选择题,填空题题等 */
    private Integer selectType;
    /** 八股文主题，例如 Java 后端、数据库、Spring */
    private String topic = "Java 后端";
    /** 技术水平：初级/中级/高级 */
    private String stackLevel = "中级";
    /** 需要生成的题目数量 */
    private Integer count = 5;
    /** 输出语言 */
    private String language = "中文";
    /** 风格补充，例如 精简/详细/场景化 */
    private String style = "精简";
}

