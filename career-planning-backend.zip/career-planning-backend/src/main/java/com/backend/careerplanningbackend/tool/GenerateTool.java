package com.backend.careerplanningbackend.tool;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class GenerateTool {

//    @Tool(description = "Function的功能描述，将来会作为提示词的一部分，大模型依据这里的描述判断何时调用该函数")
    @Tool(description = "生成有关于程序员具体岗位所对应的八股文,这是用来测试这位程序员的基础知识扎不扎实")
    public void generate(@ToolParam(description = "岗位名称，例如：Java后端开发工程师") String topic,
                         @ToolParam(description = "技术级别，例如：初级、中级、高级") String stackLevel,
                         @ToolParam(description = "选择题,判断题,填空题(大题-场景题目") String selectType
    ) {
        // 这里可以放一些生成八股文问答的逻辑，或者调用已有的服务方法
        log.info("这是一个生成八股文问答的工具方法，可以在这里实现具体的生成逻辑。");
    }

    @Tool(description = "这是用来判断这位程序员的回答水平怎么样")
    public void judgment(@ToolParam(description = "程序员岗位八股文的问题") String question,
                         @ToolParam(description = "回答") String answer,
                         @ToolParam(description = "选择题,判断题,填空题(大题-场景题目") String selectType
    ) {
        // 这里可以放一些生成八股文问答的逻辑，或者调用已有的服务方法
        log.info("这是一个反馈八股文问答的工具方法，可以在这里实现具体的生成逻辑。");
    }
}
